# Pawffee Break - WordPress theme excerpt

This is an **excerpt** of the customised child theme used for an academic pet-café/adoption WordPress site. It is not a stand-alone site and cannot run on GitHub Pages: WordPress requires PHP and a database.

The full assignment also contained WordPress core, third-party plugins, a database export and an environment-specific wp-config.php. Those are intentionally NOT published, to avoid disclosing credentials and unrelated third-party sources.

To inspect the theme, review `style.css`, `theme.json`, and `parts/footer.html`. The screenshot/case study on the portfolio shows the site design and page organization. The parent theme is Twenty Twenty-Five; see the GPL licensing in the theme readme.
