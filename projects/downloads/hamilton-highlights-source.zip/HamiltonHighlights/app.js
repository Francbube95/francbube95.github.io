/* Hamilton Highlights: map interactions and UI behaviour. */

let map;
let geocoder;
let directionsService;
let directionsRenderer;

let markers = [];
let userMarker = null;

// Track current filter so dropdown can match what’s visible
let currentFilter = "all";

// Keep visible destination markers here
let visibleDestinationMarkers = [];

// TOURIST SPOTS

const defaultPlaces = [
    { name: "Dundurn Castle", type: "landmark", lat: 43.2723, lng: -79.8913, desc: "Historic mansion and museum." },
    { name: "HMCS Haida", type: "landmark", lat: 43.2770, lng: -79.8678, desc: "Naval warship museum." },
    { name: "Battlefield House", type: "landmark", lat: 43.2177, lng: -79.7676, desc: "War of 1812 historic site." },

    { name: "Art Gallery of Hamilton", type: "museum", lat: 43.2576, lng: -79.8729, desc: "Major Canadian art gallery." },
    { name: "Canadian Warplane Heritage Museum", type: "museum", lat: 43.1631, lng: -79.9265, desc: "Aviation history museum." },

    { name: "Bayfront Park", type: "nature", lat: 43.2765, lng: -79.8727, desc: "Waterfront park and trails." },
    { name: "Gage Park", type: "nature", lat: 43.2412, lng: -79.8193, desc: "Large park and greenhouse." },
    { name: "Royal Botanical Gardens", type: "nature", lat: 43.2927, lng: -79.8865, desc: "Botanical gardens and trails." },
    { name: "Devil's Punchbowl", type: "nature", lat: 43.2046, lng: -79.7662, desc: "Scenic waterfall lookout." },

    { name: "Hamilton Farmers' Market", type: "food", lat: 43.2557, lng: -79.8736, desc: "Indoor public market." },
    { name: "Locke Street South", type: "food", lat: 43.2522, lng: -79.8847, desc: "Shops and restaurants." },
    { name: "James Street North", type: "food", lat: 43.2621, lng: -79.8678, desc: "Arts and dining district." }
];

// INIT MAP 
function initMap() {
    map = new google.maps.Map(document.getElementById("map"), {
        center: { lat: 43.2557, lng: -79.8711 }, // Hamilton
        zoom: 12
    });

    geocoder = new google.maps.Geocoder();
    directionsService = new google.maps.DirectionsService();
    directionsRenderer = new google.maps.DirectionsRenderer({ suppressMarkers: false });
    directionsRenderer.setMap(map);

    loadDefaultMarkers();
}

// LOAD DEFAULT MARKERS 
function loadDefaultMarkers() {
    defaultPlaces.forEach(p => {
        createMarker(p.name, p.desc, p.type, p.lat, p.lng);
    });
    updateDestinationList();
}

// CREATE MARKER 
function createMarker(name, desc, type, lat, lng) {
    const marker = new google.maps.Marker({
        position: { lat, lng },
        map
    });

    marker.placeType = type;
    marker.placeName = name;

    const infoWindow = new google.maps.InfoWindow({
        content: `
            <div style="max-width: 220px;">
                <h6 class="mb-1">${escapeHtml(name)}</h6>
                <p class="mb-1">${escapeHtml(desc)}</p>
                <small>Category: ${escapeHtml(type)}</small>
            </div>
        `
    });

    marker.addListener("click", () => infoWindow.open(map, marker));

    markers.push(marker);

    // Apply current filter so visibility is correct
    applyCurrentFilterToMarker(marker);
    // Return marker so other functions can use it if needed
    return marker;
}

// FILTER 
function filterMarkers(type) {
    currentFilter = type;

    markers.forEach(marker => applyCurrentFilterToMarker(marker));

    // Dropdown should match visible markers
    updateDestinationList();
}
function applyCurrentFilterToMarker(marker) {
    const shouldShow = (currentFilter === "all" || marker.placeType === currentFilter);
    marker.setMap(shouldShow ? map : null);
}
// GEOLOCATION 
function getUserLocation() {
    const geoErrorEl = document.getElementById("geoError");
    geoErrorEl.innerText = "";

    if (!navigator.geolocation) {
        geoErrorEl.innerText = "Geolocation not supported by your browser.";
        return;
    }

    navigator.geolocation.getCurrentPosition(
        position => {
        const lat = position.coords.latitude;
        const lng = position.coords.longitude;

        if (userMarker) userMarker.setMap(null);

        userMarker = new google.maps.Marker({
            position: { lat, lng },
            map,
            title: "Your Location",
            icon: "https://maps.google.com/mapfiles/ms/icons/blue-dot.png"
        });

        map.panTo({ lat, lng });
        map.setZoom(Math.max(map.getZoom(), 13));
        },
        err => {
        if (err && err.code === 1) geoErrorEl.innerText = "Location permission denied.";
        else geoErrorEl.innerText = "Unable to get your location.";
        },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );
}

// ADD LOCATION 
function addLocation() {
    const name = document.getElementById("nameInput").value.trim();
    const desc = document.getElementById("descInput").value.trim();
    const address = document.getElementById("addressInput").value.trim();
    const type = document.getElementById("typeInput").value;

    if (!name || !desc || !address) {
        alert("Please fill in Place Name, Description, and Address.");
        return;
    }

    
    const addressWithContext = address.toLowerCase().includes("hamilton")
        ? address
        : `${address}, Hamilton, ON`;

    geocoder.geocode({ address: addressWithContext }, (results, status) => {
        if (status === "OK" && results && results[0]) {
        const loc = results[0].geometry.location;

        createMarker(name, desc, type, loc.lat(), loc.lng());

        map.panTo(loc);
        map.setZoom(Math.max(map.getZoom(), 13));

        updateDestinationList();
        clearForm();
        } else {
        alert("Geocoding failed: " + status);
        }
    });
}
function clearForm() {
    document.getElementById("nameInput").value = "";
    document.getElementById("descInput").value = "";
    document.getElementById("addressInput").value = "";
    document.getElementById("typeInput").value = "landmark";
}

// DIRECTIONS
function updateDestinationList() {
    const select = document.getElementById("destinationSelect");
    select.innerHTML = "";

    const visibleMarkers = markers.filter(m => m.getMap() !== null);

    if (visibleMarkers.length === 0) {
        const opt = document.createElement("option");
        opt.value = "";
        opt.text = "No destinations (change filter)";
        select.appendChild(opt);
        select.disabled = true;
        visibleDestinationMarkers = [];
        return;
    }

    select.disabled = false;

    const sorted = visibleMarkers
        .map(m => ({ name: m.placeName, marker: m }))
        .sort((a, b) => a.name.localeCompare(b.name));

    visibleDestinationMarkers = sorted.map(x => x.marker);

    sorted.forEach((entry, idx) => {
        const option = document.createElement("option");
        option.value = String(idx);
        option.text = entry.name;
        select.appendChild(option);
    });

    // Reset selection to avoid stale index after filtering
    select.selectedIndex = 0;
}
function getDirections() {
    if (!userMarker) {
        alert("Please click 'Use My Location' first.");
        return;
    }

    const select = document.getElementById("destinationSelect");

    if (select.disabled || visibleDestinationMarkers.length === 0) {
        alert("No destination available. Try changing the filter.");
        return;
    }

    const index = parseInt(select.value, 10);
    const destinationMarker = visibleDestinationMarkers[index];

    if (!destinationMarker) {
        alert("Please select a destination.");
        return;
    }

    const request = {
        origin: userMarker.getPosition(),
        destination: destinationMarker.getPosition(),
        travelMode: google.maps.TravelMode.DRIVING
    };

    directionsService.route(request, (result, status) => {
        if (status === "OK") {
        directionsRenderer.setDirections(result);
        } else {
        alert("Directions failed: " + status);
        }
    });
}
// clear route
function clearDirections() {
    directionsRenderer.setDirections({ routes: [] });
}
// HELPERS 
function escapeHtml(str) {
    return String(str)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}





