# Hamilton Highlights - source excerpt

An academic JavaScript/Bootstrap/Google Maps application for browsing Hamilton destinations.

## Features
- Filter markers by landmarks, museums, nature and food
- Use browser geolocation (permission required)
- Add a custom location using Google Maps Geocoding
- Select a destination and request driving directions

## Running locally
1. Open `index.html` in an editor and replace `YOUR_BROWSER_KEY` with **your own** appropriately restricted Google Maps JavaScript API key.
2. Set up billing and enable the necessary Maps/Geocoding/Directions services for that key in Google Cloud.
3. Restrict that API key to allowed HTTP referrers and only necessary APIs. Never commit unrestricted credentials.
4. Serve locally using a development web server to use browser geolocation; your browser may require HTTPS for non-local hosts.

The original student source embedded a Google Maps API key and was not appropriate to distribute unchanged; this public copy has been sanitised. The source requires API configuration to run, so the portfolio shows a verified screenshot rather than promising an immediately playable demo.
